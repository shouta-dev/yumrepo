module Mod
  module_function
  def foo
    puts "hello"
    puts "goodbye"
  end
  
end

class Foo
  def dummy
  end
 
  attr_accessor :bye
 
  define_method(:fie) do
    puts "hi"
  end
  alias_method :doda, :dummy
end

foo = Mod.method(:foo)
puts foo.__line__
puts foo.__file__
fie = Foo.instance_method(:fie)
puts fie.__line__
puts fie.__file__
doda = Foo.instance_method(:doda)
puts doda.__line__
puts doda.__file__
bye = Foo.instance_method(:bye)
puts bye.__line__
puts bye.__file__
