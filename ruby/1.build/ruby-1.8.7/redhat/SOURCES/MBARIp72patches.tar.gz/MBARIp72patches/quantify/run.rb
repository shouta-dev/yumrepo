#!../rubyinst/bin/ruby

onlyMatching = (ARGV[0] if ARGV.length)

Dir.open("cases") { |d|
  toRun = Array.new
  d.each { |f|
    if (f.match(/rb$/) && (onlyMatching.nil? || f.match(onlyMatching))) then
      toRun.push(f) 
    end
  }

  toRun.each { |f|
    print "running cases/#{f} "
    pid = Process.fork {
      GC.start
      start=Time.now
      require("cases/" + f)      
      print "#{' '*(30-f.size)} time %7.3f\n"%(Time.now - start)
      exit 0
    }
    Process.wait
  }
}
