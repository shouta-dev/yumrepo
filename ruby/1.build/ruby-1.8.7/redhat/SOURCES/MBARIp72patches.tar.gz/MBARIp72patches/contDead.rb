#!/usr/bin/env ruby
#Crashes 1.8.6 & 1.6.8 as of Dec 5th, 2007
#submitted by brent@mbari.org

def nestedThreadBug
 inner = nil
 outer = Thread.new(Thread.current) do |passedThread|
   $c4 = callcc {|c| c}
   inner = Thread.new passedThread do
   end
 end
 yield(outer)
 outer.value
 inner
end

loop {
 inner = nestedThreadBug do |thread|
  thread.value
 end
 inner.join
}
