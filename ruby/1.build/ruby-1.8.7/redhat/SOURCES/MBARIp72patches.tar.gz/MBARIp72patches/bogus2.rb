$depth = 0

def outer name
  ball = Thread.current
  inner = Thread.new Thread.current do | outer |
    loop {
      Thread.stop until (Thread.critical=true; ball == inner)
      (ball=outer).run
    }
  end
  2000.times {|i|  
    Thread.stop until (Thread.critical=true; ball == Thread.current)
    (ball=inner).run
  }
end

def recurse someArg
  if ($depth+=1) < 2000
    recurse 3.14159
  else
    outer :outer
  end
end

recurse "top"
