#!/usr/bin/env ruby
# quick demo of the speed up possible by trapping SIGCHLD 
# instead of waiting for Ruby's internal rbthreadpoll()
# A proof up concept for a possible patch

n = 100

def nullShell
  pid = fastShell
  Process.waitall
end

def fastShell
  fork {
    exec "echo", "-n", "#"
  }
end

def time
  start = Time.now
  yield
  Time.now - start
end

Thread.new {
  t=Thread.current
  puts time{n.times{nullShell}}

  Signal.trap("CHLD") {
    t.wakeup  #Ruby traps run on the Thread.main
  }

  puts time{n.times{nullShell}}
}.join
