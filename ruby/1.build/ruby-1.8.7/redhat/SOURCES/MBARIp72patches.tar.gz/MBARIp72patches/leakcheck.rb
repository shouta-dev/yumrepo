#!/usr/bin/env ruby
#heap grows quickly without bound on all unpatched versions of MRI
#even MBARI 7/0x2020 fixes this simple case of a leak caused by ghost
#object references left on the call stack.
#MBARI 7/0x2370 is recommended for more complex cases.

loop do
  @x=callcc{|c|c}
end
